
#include <cmath>
#include <cstdlib>
#include <string>
#include "system.h"

using namespace std;
using namespace arma;

void System :: step(){ // Perform a simulation step
  this->Brownian();
  _t += _delta; // Aggiorna il tempo fisico della simulazione
  _nattempts += _npart; 
  return;
}

void System :: Brownian(){
  double xnew, ynew;
  double mu = 1.0;     // Mobilita' (gamma = 1/mu = 1)
  double D = _temp;    // Coefficiente di diffusione D = mu * k_B * T (con k_B = 1)

  for(int i=0; i<_npart; i++){ // Calcolo forze interparticellari
    _fx(i) = this->Force(i,0);
    _fy(i) = this->Force(i,1);
    
    // Aggiunta della forzante esterna attiva (applicata lungo l'asse X)
    if(_is_active(i) == 1){
        _fx(i) += _A_ext * sin(_omega_ext * _t);
    }
  }

  for(int i=0; i<_npart; i++){ // Integrazione di Langevin sovrasmorzata
    // Rumore gaussiano (stocastico)
    double noise_x = sqrt(2.0 * D * _delta) * _rnd.Gauss(0.0, 1.0);
    double noise_y = sqrt(2.0 * D * _delta) * _rnd.Gauss(0.0, 1.0);

    // Spostamento infinitesimo reale
    double dx = mu * _fx(i) * _delta + noise_x;
    double dy = mu * _fy(i) * _delta + noise_y;

    // Aggiornamento coordinate "unwrapped" (per il calcolo dell'MSD)
    _particle(i).add_unwrapped(0, dx);
    _particle(i).add_unwrapped(1, dy);

    // Calcolo posizioni finali dentro il box tramite PBC
    xnew = this->pbc( _particle(i).getposition(0,true) + dx, 0);
    ynew = this->pbc( _particle(i).getposition(1,true) + dy, 1);

    // Salvataggio della "velocita' istantanea" utile per calcolare la potenza dissipata
    _particle(i).setvelocity(0, dx / _delta);
    _particle(i).setvelocity(1, dy / _delta);

    _particle(i).acceptmove(); // _xold = _x
    _particle(i).setposition(0, xnew);
    _particle(i).setposition(1, ynew);
  }
  _naccepted += _npart;
  return;
}

double System :: Force(int i, int dim){
  double f=0.0, dr;
  vec distance;
  distance.resize(_ndim);
  for (int j=0; j<_npart; j++){
    if(i != j){
      distance(0) = this->pbc( _particle(i).getposition(0,true) - _particle(j).getposition(0,true), 0);
      distance(1) = this->pbc( _particle(i).getposition(1,true) - _particle(j).getposition(1,true), 1);
      dr = sqrt( dot(distance,distance) );
      if(dr < _r_cut){
        f += distance(dim) * (48.0/pow(dr,14) - 24.0/pow(dr,8));
      }
    }
  }
  return f;
}

double System :: pbc(double position, int i){ // Enforce periodic boundary conditions
  return position - _side(i) * rint(position / _side(i));
}

void System :: initialize(){ // Initialize the System object

  int p1, p2; 
  ifstream Primes("../INPUT/Primes");
  if(Primes.is_open()) {
    Primes >> p1 >> p2 ;
  } else {
    cerr << "PROBLEM: Unable to open Primes" << endl;
    exit(EXIT_FAILURE); // # Se manca un file cruciale, il programma deve abortire per non calcolare fisica su memoria sporca
  }
  Primes.close();
  
  int seed[4]; 
  ifstream Seed("../INPUT/seed.in");
  if(Seed.is_open()) {
    Seed >> seed[0] >> seed[1] >> seed[2] >> seed[3];
  } else {
    cerr << "PROBLEM: Unable to open seed.in" << endl;
    exit(EXIT_FAILURE);
  }
  _rnd.SetRandom(seed,p1,p2);

  ifstream input("../INPUT/input.dat"); 
  if(!input.is_open()) {
    cerr << "PROBLEM: Unable to open input.dat" << endl;
    exit(EXIT_FAILURE);
  }
  
  ofstream coutf;
  coutf.open("../OUTPUT/output.dat");
  string property;
  double delta;
  
  _t = 0.0; // Inizializzazione del tempo

  // # Sostituito !input.eof() con (input >> property)
  // # L'operatore >> restituisce falso appena incontra un errore o la fine vera del file, prevenendo i loop infiniti
  while ( input >> property ){
    if( property == "SIMULATION_TYPE" ){
      input >> _sim_type;
      coutf << "BROWNIAN DYNAMICS 2D SIMULATION" << endl;
    } else if( property == "RESTART" ){
      input >> _restart;
    } else if( property == "TEMP" ){
      input >> _temp;
      coutf << "TEMPERATURE= " << _temp << endl;
    } else if( property == "NPART" ){
      input >> _npart;
      _fx.resize(_npart);
      _fy.resize(_npart);
      _is_active.resize(_npart);
      _particle.set_size(_npart);
      for(int i=0; i<_npart; i++){ 
        _particle(i).initialize();
      }
      coutf << "NPART= " << _npart << endl;
    } else if( property == "RHO" ){
      input >> _rho;
      _volume = _npart/_rho; // In 2D, il "volume" e' l'area
      _side.resize(_ndim);
      _halfside.resize(_ndim);
      double side = sqrt(_volume); // Radice quadrata per area 2D
      for(int i=0; i<_ndim; i++) _side(i) = side;
      _halfside=0.5*_side;
      coutf << "SIDE= " << _side(0) << endl;
    } else if( property == "R_CUT" ){
      input >> _r_cut;
      coutf << "R_CUT= " << _r_cut << endl;
    } else if( property == "DELTA" ){
      input >> delta;
      coutf << "DELTA= " << delta << endl;
      _delta = delta;
    } else if( property == "NBLOCKS" ){
      input >> _nblocks;
      coutf << "NBLOCKS= " << _nblocks << endl;
    } else if( property == "NSTEPS" ){
      input >> _nsteps;
      coutf << "NSTEPS= " << _nsteps << endl;
    } else if( property == "ACTIVE_FRACTION" ){
      input >> _active_fraction;
      coutf << "ACTIVE_FRACTION= " << _active_fraction << endl;
    } else if( property == "A_EXT" ){
      input >> _A_ext;
      coutf << "A_EXT= " << _A_ext << endl;
    } else if( property == "OMEGA_EXT" ){
      input >> _omega_ext;
      coutf << "OMEGA_EXT= " << _omega_ext << endl;
    } else if( property == "ENDINPUT" ){
      coutf << "Reading input completed!" << endl;
      break;
    } else {
      cerr << "PROBLEM: unknown input -> " << property << endl;
      // # Rimuovi il break qui, cosi' ignora stringhe estranee e continua a cercare ENDINPUT
    }
  }
  input.close();
  
  // Assegnazione casuale particelle attive
  _is_active.zeros();
  int num_active = round(_active_fraction * _npart);
  int assigned = 0;
  while(assigned < num_active){
      int idx = int(_rnd.Rannyu() * _npart);
      if(_is_active(idx) == 0){
          _is_active(idx) = 1;
          assigned++;
      }
  }

  this->read_configuration();
  this->initialize_velocities();
  coutf << "System initialized!" << endl;
  coutf.close();
  return;
}

void System :: read_configuration(){
  ifstream cinf;
  cinf.open("../INPUT/CONFIG/config.xyz");
  if(cinf.is_open()){
    string comment;
    string particle;
    double x, y;
    int ncoord;
    cinf >> ncoord;
    if (ncoord != _npart){
      cerr << "PROBLEM: conflicting number of coordinates in input.dat & config.xyz not match!" << endl;
      exit(EXIT_FAILURE);
    }
    getline(cinf, comment); 
    getline(cinf, comment); 
    for(int i=0; i<_npart; i++){
      cinf >> particle >> x >> y; // Letto rigorosamente in 2D
      _particle(i).setposition(0, this->pbc(_side(0)*x, 0));
      _particle(i).setposition(1, this->pbc(_side(1)*y, 1));
      _particle(i).set_unwrapped(0, this->pbc(_side(0)*x, 0)); 
      _particle(i).set_unwrapped(1, this->pbc(_side(1)*y, 1)); 
      _particle(i).acceptmove(); 
    }
  } else {
    cerr << "PROBLEM: Unable to open INPUT file config.xyz"<< endl;
    exit(EXIT_FAILURE); // # Fondamentale: impedisce la sovrapposizione mortale delle particelle nell'origine
  }
  cinf.close();
  return;
}
void System :: initialize_velocities(){
  // Nella dinamica browniana la velocita' inerziale si perde istantaneamente.
  // Inizializziamo a zero.
  for (int i=0; i<_npart; i++){
    _particle(i).setvelocity(0, 0.0);
    _particle(i).setvelocity(1, 0.0);
  }
  return;
}

void System :: initialize_properties(){ // Initialize data members used for measurement of properties

  string property;
  int index_property = 0;
  _nprop = 0;

  _measure_penergy  = false; 
  _measure_pressure = false;
  _measure_gofr     = false;
  _measure_power    = false; 

  ifstream input("../INPUT/properties.dat");
  if (input.is_open()){
    
    // Il ciclo di lettura sicuro: si ferma automaticamente se incontra 
    // una riga vuota, un errore di lettura o la fine reale del file.
    while ( input >> property ){
      if( property == "POTENTIAL_ENERGY" ){
        ofstream coutp("../OUTPUT/potential_energy.dat");
        coutp << "#     BLOCK:  ACTUAL_PE:     PE_AVE:      ERROR:" << endl;
        coutp.close();
        _nprop++;
        _index_penergy = index_property;
        _measure_penergy = true;
        index_property++;
      } else if( property == "PRESSURE" ){
        ofstream coutpr("../OUTPUT/pressure.dat");
        coutpr << "#     BLOCK:   ACTUAL_P:     P_AVE:       ERROR:" << endl;
        coutpr.close();
        _nprop++;
        _measure_pressure = true;
        _index_pressure = index_property;
        index_property++;
      } else if( property == "DISSIPATED_POWER" ){
        ofstream coutpow("../OUTPUT/dissipated_power.dat");
        coutpow << "#     BLOCK:   ACTUAL_POW:   POW_AVE:     ERROR:" << endl;
        coutpow.close();
        _nprop++;
        _measure_power = true;
        _index_power = index_property;
        index_property++;
      } else if( property == "GOFR" ){
        ofstream coutgr("../OUTPUT/gofr.dat");
        coutgr << "# DISTANCE:     AVE_GOFR:        ERROR:" << endl;
        coutgr.close();
        input>>_n_bins;
        _nprop+=_n_bins;
        _bin_size = (_halfside.min() )/(double)_n_bins;
        _measure_gofr = true;
        _index_gofr = index_property;
        index_property+= _n_bins;
      } else if( property == "ENDPROPERTIES" ){
        ofstream coutf;
        coutf.open("../OUTPUT/output.dat",ios::app);
        coutf << "Reading properties completed!" << endl;
        coutf.close();
        break;
      } else {
        cerr << "PROBLEM: unknown property -> " << property << endl;
      }
    }
    input.close();
  } else {
    cerr << "PROBLEM: Unable to open properties.dat" << endl;
    exit(EXIT_FAILURE); // Interrompe l'esecuzione se manca il file
  }

  _measurement.resize(_nprop);
  _average.resize(_nprop);
  _block_av.resize(_nprop);
  _global_av.resize(_nprop);
  _global_av2.resize(_nprop);
  _average.zeros();
  _global_av.zeros();
  _global_av2.zeros();
  _nattempts = 0;
  _naccepted = 0;
  return;
}

void System :: finalize(){
  this->write_configuration();
  _rnd.SaveSeed();
  ofstream coutf;
  coutf.open("../OUTPUT/output.dat",ios::app);
  coutf << "Simulation completed!" << endl;
  coutf.close();
  return;
}

void System :: write_configuration(){
  ofstream coutf;
  coutf.open("../OUTPUT/CONFIG/config.xyz");
  if(coutf.is_open()){
    coutf << _npart << endl;
    coutf << "Final Configuration 2D" << endl;
    for(int i=0; i<_npart; i++){
      coutf << "LJ" << "  " 
            << setw(16) << _particle(i).getposition(0,true)/_side(0)          
            << setw(16) << _particle(i).getposition(1,true)/_side(1) << endl; 
    }
  } else cerr << "PROBLEM: Unable to open config.xyz" << endl;
  coutf.close();
  this->write_velocities();
  return;
}

void System :: write_XYZ(int nconf){
  ofstream coutf;
  coutf.open("../OUTPUT/CONFIG/config_" + to_string(nconf) + ".xyz");
  if(coutf.is_open()){
    coutf << _npart << endl;
    coutf << "Wrapped coordinates 2D" << endl;
    for(int i=0; i<_npart; i++){
      coutf << "LJ" << "  " 
            << setw(16) << _particle(i).getposition(0,true)          
            << setw(16) << _particle(i).getposition(1,true) << endl; 
    }
  } else cerr << "PROBLEM: Unable to open config.xyz" << endl;
  coutf.close();
  return;
}

void System :: write_unwrapped(int nconf){
  ofstream coutf;
  coutf.open("../OUTPUT/CONFIG/unwrapped_" + to_string(nconf) + ".xyz");
  if(coutf.is_open()){
    coutf << _npart << endl;
    coutf << "Unwrapped coordinates for MSD 2D" << endl;
    for(int i=0; i<_npart; i++){
      coutf << "LJ" << "  " 
            << setw(16) << _particle(i).get_unwrapped(0)          
            << setw(16) << _particle(i).get_unwrapped(1) << endl; 
    }
  } else cerr << "PROBLEM: Unable to open unwrapped file" << endl;
  coutf.close();
  return;
}

void System :: write_velocities(){
  ofstream coutf;
  coutf.open("../OUTPUT/CONFIG/velocities.out");
  if(coutf.is_open()){
    for(int i=0; i<_npart; i++){
      coutf << setw(16) << _particle(i).getvelocity(0)          
            << setw(16) << _particle(i).getvelocity(1) << endl; 
    }
  } else cerr << "PROBLEM: Unable to open velocities.out" << endl;
  coutf.close();
  return;
}


void System :: block_reset(int blk){ 
  ofstream coutf;
  if(blk>0){
    coutf.open("../OUTPUT/output.dat",ios::app);
    coutf << "Block completed: " << blk << endl;
    coutf.close();
  }
  _block_av.zeros();
  return;
}

void System :: measure(){ 
  _measurement.zeros();
  vec distance;
  distance.resize(_ndim);
  double penergy_temp=0.0, dr; 
  double virial=0.0;
  double power_temp=0.0;

  // 1. Calcolo Energia Potenziale e Pressione (Viriale)
  if (_measure_penergy or _measure_pressure or _measure_gofr) {
    for (int i=0; i<_npart-1; i++){
      for (int j=i+1; j<_npart; j++){
        distance(0) = this->pbc( _particle(i).getposition(0,true) - _particle(j).getposition(0,true), 0);
        distance(1) = this->pbc( _particle(i).getposition(1,true) - _particle(j).getposition(1,true), 1);
        dr = sqrt( dot(distance,distance) );
        
        if(dr < _r_cut){
          if(_measure_penergy)  penergy_temp += 1.0/pow(dr,12) - 1.0/pow(dr,6) + 0.25; //shiftato per essere zero al cutoff
          if(_measure_pressure) virial += 1.0/pow(dr,12) - 0.5/pow(dr,6);
        }
        if(_measure_gofr){
    if(dr < _halfside.min()){ // Consideriamo solo distanze entro meta' del box
        int bin = int(dr / _bin_size);
        _measurement(_index_gofr + bin) += 2.0; // +2 perche' la coppia (i,j) conta per entrambi
    }
}
      }
    }
  }

  // 2. Calcolo Potenza Dissipata (F_ext * v_x)
  if (_measure_power){
    for (int i=0; i<_npart; i++){
      if(_is_active(i) == 1){
        double f_ext_inst = _A_ext * sin(_omega_ext * _t);
        power_temp += f_ext_inst * _particle(i).getvelocity(0);
      }
    }
    _measurement(_index_power) = power_temp / double(_npart); // Potenza dissipata per particella
  }

  if (_measure_penergy){
    penergy_temp = 4.0 * penergy_temp / double(_npart);
    _measurement(_index_penergy) = penergy_temp;
  }
  
  if (_measure_pressure) {
    // In 2D: P = rho * k_B * T + (1 / 2A) * < sum(r_ij * F_ij) >
    _measurement(_index_pressure) = _rho * _temp + 48.0 / (2.0 * _volume) * virial;
  }

  _block_av += _measurement; 
  return;
}

void System :: averages(int blk){
  ofstream coutf;
  double average, sum_average, sum_ave2;

  _average     = _block_av / double(_nsteps);
  _global_av  += _average;
  _global_av2 += _average % _average; 

  if (_measure_penergy){
    coutf.open("../OUTPUT/potential_energy.dat",ios::app);
    average  = _average(_index_penergy);
    sum_average = _global_av(_index_penergy);
    sum_ave2 = _global_av2(_index_penergy);
    coutf << setw(12) << blk 
          << setw(12) << average
          << setw(12) << sum_average/double(blk)
          << setw(12) << this->error(sum_average, sum_ave2, blk) << endl;
    coutf.close();
  }
  
  if (_measure_pressure){
    coutf.open("../OUTPUT/pressure.dat",ios::app);
    average  = _average(_index_pressure);
    sum_average = _global_av(_index_pressure);
    sum_ave2 = _global_av2(_index_pressure);
    coutf << setw(12) << blk
          << setw(12) << average
          << setw(12) << sum_average/double(blk)
          << setw(12) << this->error(sum_average, sum_ave2, blk) << endl;
    coutf.close();
  }

  if (_measure_power){
    coutf.open("../OUTPUT/dissipated_power.dat",ios::app);
    average  = _average(_index_power);
    sum_average = _global_av(_index_power);
    sum_ave2 = _global_av2(_index_power);
    coutf << setw(12) << blk
          << setw(12) << average
          << setw(12) << sum_average/double(blk)
          << setw(12) << this->error(sum_average, sum_ave2, blk) << endl;
    coutf.close();
  }
  
  if (_measure_gofr) {
    // Stampiamo la g(r) solo alla fine dell'ultimo blocco per avere la curva finale pulita
    if(blk == _nblocks){
      coutf.open("../OUTPUT/gofr.dat");
      coutf << "# DISTANCE:     AVE_GOFR:        ERROR:" << endl;
      
      for (int i=0; i<_n_bins; i++) {
        double r = i * _bin_size;
        
        // 1. Calcolo dell'area dell'anello in 2D
        double deltaA = M_PI * (pow(r + _bin_size, 2) - pow(r, 2));
        
        // 2. Fattore di normalizzazione (gas ideale)
        double norm = _rho * double(_npart) * deltaA;
        
        // 3. Estrazione dei valori globali e normalizzazione
        // _global_av contiene la somma delle medie dei blocchi, quindi dividiamo per norm
        double sum_ave = _global_av(_index_gofr + i) / norm;
        double sum_ave2 = _global_av2(_index_gofr + i) / pow(norm, 2);
        
        coutf << setw(12) << r + _bin_size/2.0 // Stampiamo il centro del bin
              << setw(12) << sum_ave / double(blk)
              << setw(12) << this->error(sum_ave, sum_ave2, blk) << endl;
      }
      coutf.close();
    }
  }
  double fraction;
  coutf.open("../OUTPUT/acceptance.dat",ios::app);
  if(_nattempts > 0) fraction = double(_naccepted)/double(_nattempts);
  else fraction = 0.0; 
  coutf << setw(12) << blk << setw(12) << fraction << endl;
  coutf.close();
  
  return;
}

double System :: error(double acc, double acc2, int blk){
  if(blk <= 1) return 0.0;
  else return sqrt( fabs(acc2/double(blk) - pow( acc/double(blk) ,2) )/double(blk) );
}

int System :: get_nbl(){
  return _nblocks;
}

int System :: get_nsteps(){
  return _nsteps;
}
