
#ifndef __System__
#define __System__

#include <iostream>
#include<cmath>
#include <iomanip>
#include <fstream>
#include <string>
#include <armadillo>
#include <stdlib.h> //exit
#include "particle.h"
#include "random.h"

using namespace std;
using namespace arma;

class System {

private:
  const int _ndim = 2;  // Dimensionality of the system
  bool _restart;        // Flag indicating if the simulation is restarted
  int _sim_type;        // Type of simulation
  int _npart;           // Number of particles
  int _nblocks;         // Number of blocks for block averaging
  int _nsteps;          // Number of simulation steps in each block
  int _nattempts;       // Number of attempted moves
  int _naccepted;       // Number of accepted moves
  double _temp;         // Temperature (sets the diffusion coefficient D)
  double _rho, _volume; // Density and volume of the system
  double _r_cut;        // Cutoff radius for pair interactions (WCA)
  double _delta;        // Time step (dt) for Brownian dynamics
  vec _side;            // Box dimensions
  vec _halfside;        // Half of box dimensions
  Random _rnd;          // Random number generator
  field <Particle> _particle; // Field of particle objects representing the system
  vec _fx, _fy;         // Forces on particles along x and y directions

  // Active Matter parameters
  double _t;              // Current simulation time
  double _A_ext;          // Amplitude of external sinusoidal force
  double _omega_ext;      // Frequency of external force
  double _active_fraction;// Fraction of driven particles
  ivec _is_active;        // 1 if particle is active, 0 if passive

  // Properties
  int _nprop; // Number of properties being measured
  bool _measure_penergy, _measure_pressure, _measure_gofr;
  bool _measure_power;    // Flag to measure dissipated power
  int _index_penergy, _index_pressure, _index_gofr, _index_power;
  int _n_bins;           // Number of bins for radial distribution function
  double _bin_size;      // Size of bins for radial distribution function
  vec _block_av;         // Block averages of properties
  vec _global_av;        // Global averages of properties
  vec _global_av2;       // Squared global averages of properties
  vec _average;          // Average values of properties
  vec _measurement;      // Measured values of properties

public: // Function declarations
  int get_nbl();              // Get the number of blocks
  int get_nsteps();           // Get the number of steps in each block
  void initialize();          // Initialize system properties
  void initialize_properties();// Initialize properties for measurement
  void finalize();            // Finalize system and clean up
  void write_configuration(); // Write final system configuration to XYZ file
  void write_XYZ(int nconf);  // Write system configuration in XYZ format on the fly
  void write_unwrapped(int nconf); // Write unwrapped trajectories for MSD evaluation
  void read_configuration();  // Read system configuration from file
  void step();                // Perform a simulation step
  void block_reset(int blk);  // Reset block averages
  void measure();             // Measure properties of the system
  void averages(int blk);     // Compute averages of properties
  double error(double acc, double acc2, int blk); // Compute error
  double pbc(double position, int i); // Apply periodic boundary conditions for coordinates
  
  void Brownian();            // Perform Brownian integration step (replaces Verlet)
  double Force(int i, int dim); // Calculate force on a particle along a dimension
  void initialize_velocities(); // Aggiungi questa
  void write_velocities();      // E questa
};

#endif // __System__

