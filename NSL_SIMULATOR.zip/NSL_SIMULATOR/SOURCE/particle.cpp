
#include <iostream>
#include <math.h>
#include "particle.h"

using namespace std;

void Particle :: initialize(){
   // Ridimensiona i vettori di Armadillo per il sistema 2D
   _x.resize(_ndim);
   _xold.resize(_ndim);
   _v.resize(_ndim);
   _x_unwrapped.resize(_ndim);
   
   // Azzera esplicitamente le componenti (buona pratica per evitare memoria sporca)
   _x.zeros();
   _xold.zeros();
   _v.zeros();
   _x_unwrapped.zeros();
   
   return;
}

void Particle :: acceptmove(){
   _xold = _x;
}

double Particle :: getposition(int dim, bool xnew){
   if(xnew) return _x(dim);
   else return _xold(dim);
}

void Particle :: setposition(int dim, double position){
   _x(dim) = position;
   return;
}

void Particle :: setpositold(int dim, double position){
   _xold(dim) = position;
   return;
}

// Metodi per le posizioni unwrapped (necessari per il calcolo dell'MSD)
double Particle :: get_unwrapped(int dim){
   return _x_unwrapped(dim);
}

void Particle :: set_unwrapped(int dim, double position){
   _x_unwrapped(dim) = position;
   return;
}

void Particle :: add_unwrapped(int dim, double delta_x){
   // Accumula l'incremento di spostamento calcolato dall'integratore
   // senza applicare condizioni al contorno periodiche
   _x_unwrapped(dim) += delta_x;
   return;
}

double Particle :: getvelocity(int dim){
   return _v(dim);
}

vec Particle :: getvelocity(){
   return _v;
}

void Particle :: setvelocity(int dim, double velocity){
   _v(dim) = velocity;
   return;
}

