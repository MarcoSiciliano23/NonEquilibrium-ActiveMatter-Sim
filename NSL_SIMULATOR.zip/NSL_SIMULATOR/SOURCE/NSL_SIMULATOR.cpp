
#include <iostream>
#include "system.h"

using namespace std;

int main (int argc, char *argv[]){
  cout << "SONDA ZERO" << endl;
  int nconf = 1;
  System SYS;
  SYS.initialize();
  cout << "Initialization completed. SONDA 1" << endl;
  SYS.initialize_properties();
  cout << "Properties initialized. SONDA 2" << endl;

  //--- FASE DI EQUILIBRAZIONE (Rilassamento) ---
  // Fondamentale per smaltire le enormi forze repulsive iniziali
  // e portare il sistema in uno stato stazionario.
  cout << "Inizio fase di termalizzazione/equilibrazione..." << endl;
  int eq_steps = 5000; // Numero di step a vuoto (aggiustalo se necessario)
  for(int i=0; i < eq_steps; i++){
      SYS.step(); 
      // Non chiamiamo SYS.measure() qui, i dati iniziali non ci interessano
  }
  cout << "Equilibrazione completata. Inizio simulazione e misure." << endl;
   //---------------------------------------------

  SYS.block_reset(0);

  for(int i=0; i < SYS.get_nbl(); i++){ // loop over blocks
    for(int j=0; j < SYS.get_nsteps(); j++){ // loop over steps in a block
      
      SYS.step();    // Evoluzione temporale (Dinamica Browniana)
      SYS.measure(); // Misura energia, pressione e potenza dissipata
      
      // Salvataggio configurazioni. 
      // Il modulo dell'operazione (%) regola la frequenza di campionamento.
      // Salvare ogni 100 step è un buon compromesso tra risoluzione MSD e peso dei file.
      if(j % 100 == 0){
        SYS.write_XYZ(nconf); // Rimuovi il commento se vuoi visualizzare le particelle confinate nel box su Ovito
        //SYS.write_unwrapped(nconf); // FONDAMENTALE: Salva le traiettorie continue per l'MSD
        nconf++;
      }
    }
    SYS.averages(i+1);
    SYS.block_reset(i+1);
  }
  
  SYS.finalize();

  return 0;
}
