
#ifndef __Particle__
#define __Particle__

#include <armadillo>
#include "random.h"

using namespace std;
using namespace arma;

class Particle {

private:
  const int _ndim = 2;  // Dimensionality set to 2D for the active matter system
  vec _x;               // Current position vector (wrapped with PBC for forces)
  vec _xold;            // Previous position vector 
  vec _v;               // Velocity vector (will be useful to compute dissipated power)
  vec _x_unwrapped;     // Unwrapped position vector (strictly for MSD calculation)

public: 
  void initialize();                     // Initialize particle properties
  void acceptmove();                     // Accept the proposed move (_xold = _x)
  
  // Wrapped position methods (used for physical interactions and PBC)
  double getposition(int dim, bool xnew);
  void   setposition(int dim, double position); 
  void   setpositold(int dim, double position); 

  // Unwrapped position methods (used for data analysis)
  double get_unwrapped(int dim);
  void   set_unwrapped(int dim, double position);
  void   add_unwrapped(int dim, double delta_x); // Increment the unwrapped position by a small step

  // Velocity methods
  double getvelocity(int dim);           
  vec    getvelocity();                  
  void   setvelocity(int dim, double velocity); 

};

#endif // __Particle__

